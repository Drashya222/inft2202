export default (req, res, next) => {
    res.render('animals/show');
};